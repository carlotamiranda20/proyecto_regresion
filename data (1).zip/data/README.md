# Boxing_Champions-Final.csv and Boxing_Champs_by_Day.csv

Complete history of WBO, WBA, WBC, and IBF champions since those belts were created. In addition, we also have data for the lineal heavyweight championship. In addition to the champion, we have provided you the champion's nationality, number of defenses, and how long they held a title before they were dethroned.


# Boxrec

Data about boxing matches scrapped from boxrec.com


# boxing_matches.csv

The dataset consists of the information about boxing matches. Various variables present in the dataset includes data of age, won, knockout, height, weight,stance of boxers.
